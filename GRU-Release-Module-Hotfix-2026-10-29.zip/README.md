# GRU deployment hotfix — missing release module

The failed showreel build references `src/scripts/release.ts` from `Base.astro`, but that dependency was absent from the prior upload package.

This ZIP contains exactly that one source file. It does not alter content, media, CMS fields, or styling.

In Codespaces, upload this ZIP to the repository root, then run:

```bash
git pull --rebase origin main
unzip -o GRU-Release-Module-Hotfix-2026-10-29.zip -d /tmp/gru-release-hotfix
cp -R /tmp/gru-release-hotfix/payload/. .
git add src/scripts/release.ts
git commit -m "Add missing release policy module"
git push origin main
```
