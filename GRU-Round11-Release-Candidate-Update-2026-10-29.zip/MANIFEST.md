# GRU release-candidate update — 2026-10-29

This incremental package contains only the files required for the current release candidate:

- `package-lock.json`
- `scripts/assert-assets.mjs`
- `site.config.mjs`
- `src/scripts/motion.ts`
- `src/scripts/site.ts`
- `src/styles/global.css`
- `tests/motion.test.mjs`
- `tests/portfolio.test.mjs`
- `tests/release.test.mjs`

It does not contain content, media, CMS data, credentials, build output, or any full-project copy.

The `CHECKSUMS.sha256` file in this package records each packaged source file hash.
