# Upload through GitHub Codespaces

1. In GitHub, open `themorsy/GRU.AGENCY`, then **Code** → **Codespaces** → open your existing Codespace.
2. Upload `GRU-Round11-Release-Candidate-Update-2026-10-29.zip` into the repository root (the folder containing `package.json`).
3. In the Codespaces terminal, run these commands one at a time:

```bash
git pull --rebase origin main
unzip -o GRU-Round11-Release-Candidate-Update-2026-10-29.zip -d /tmp/gru-release-update
cp -R /tmp/gru-release-update/payload/. .
git status --short
```

4. Confirm the changed source files shown are only the eight files listed in `MANIFEST.md`. The uploaded ZIP itself may also appear as untracked; do not add it.
5. Commit and push exactly these files:

```bash
git add package-lock.json scripts/assert-assets.mjs site.config.mjs src/scripts/motion.ts src/scripts/site.ts src/styles/global.css tests/motion.test.mjs tests/portfolio.test.mjs tests/release.test.mjs
git commit -m "Harden motion fallback and prepare release candidate"
git push origin main
```

6. Cloudflare will build the new `main` branch automatically. Wait for the deployment to show **Success**, then open `https://gru.agency/en/` in an incognito window and hard refresh once.

If `git pull --rebase origin main` reports a conflict, stop before copying or committing and send me the terminal output. Do not use force-push.
