# GRU showreel hero supplement — 2026-10-29

This is a supplemental deployment package for the missing showreel hero files only.

Included files:

- `src/components/Hero.astro`
- `src/layouts/Base.astro`
- `public/assets/hero/showreel-desktop-1024x576.mp4`
- `public/assets/hero/showreel-desktop-1024x576.webm`
- `public/assets/hero/showreel-mobile-576x1024.mp4`
- `public/assets/hero/showreel-poster-1440x720.jpg`

The accompanying command updates only the four hero-media values in `src/content/pages/home.json` for English and Arabic. It preserves all other CMS text, portfolio, gallery, and page content exactly as it is in GitHub.
