# Install the showreel hero supplement in Codespaces

1. Upload this ZIP to the repository root in Codespaces.
2. Run each command below in the terminal.

```bash
git pull --rebase origin main
unzip -o GRU-Showreel-Hero-Supplement-2026-10-29.zip -d /tmp/gru-showreel-update
cp -R /tmp/gru-showreel-update/payload/. .
node -e "const fs=require('fs');const file='src/content/pages/home.json';const page=JSON.parse(fs.readFileSync(file,'utf8'));for(const lang of ['en','ar'])Object.assign(page.content[lang].hero,{video:'/assets/hero/showreel-desktop-1024x576.mp4',videoWebm:'/assets/hero/showreel-desktop-1024x576.webm',videoMobile:'/assets/hero/showreel-mobile-576x1024.mp4',poster:'/assets/hero/showreel-poster-1440x720.jpg'});fs.writeFileSync(file,JSON.stringify(page,null,2)+'\\n');"
git status --short
```

3. Confirm the changed files are the six package files plus `src/content/pages/home.json`. Do not add the ZIP itself.
4. Commit and push:

```bash
git add src/components/Hero.astro src/layouts/Base.astro public/assets/hero/showreel-desktop-1024x576.mp4 public/assets/hero/showreel-desktop-1024x576.webm public/assets/hero/showreel-mobile-576x1024.mp4 public/assets/hero/showreel-poster-1440x720.jpg src/content/pages/home.json
git commit -m "Add approved showreel hero"
git push origin main
```

Cloudflare will deploy the change automatically. Verify that the live page video source includes `showreel-desktop-1024x576.webm`.
